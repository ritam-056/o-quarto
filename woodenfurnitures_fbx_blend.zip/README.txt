LICENSE: Creative Commons 0/ CC0

free to use these game assets in any project, personal or commercial. There's no need to ask permission before using these. Giving attribution is not required, but is greatly appreciated!

Thanks for Downloading!!!

 
check for updates here https://twitter.com/TheLoafbrr and https://loafbrr.itch.io/


Please help me by supporting the patreon
https://patreon.com/loafbrr

